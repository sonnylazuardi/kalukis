({
  appDir: '../',
  baseUrl: 'src',
  dir: '../../build',
  name: 'main',
  mainConfigFile: 'main.js',
  optimize: 'uglify2',
  optimizeCss: 'standard',
  include: ['../../vendor/requirejs/require']
})